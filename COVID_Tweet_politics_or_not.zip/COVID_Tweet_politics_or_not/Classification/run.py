import numpy as np
import pandas as pd
from transformers import pipeline
from transformers import AutoTokenizer, AutoModelForSequenceClassification, AutoConfig

THRESHOLD = 50
INPUT_FILE_PATH = "tweets.csv"
TOPICS = ["public health", "politics"]
DEFAULT_TOPIC = "ambiguous"
OUTPUT_COLUMNS = ["Public_Health_score", "Politics_score", "Predicted_Label"]

df = pd.read_csv(INPUT_FILE_PATH)
tweets = df["Clean_Tweet"]

tweets_df = pd.DataFrame(tweets)
tweets_df.columns = ["Tweet"]

MODEL_NAMES = [ "bart-large-mnli",
                "distilbart-mnli-12-1",
                "distilbart-mnli-12-3",
                "distilbart-mnli-12-6",
                "distilbart-mnli-12-9",
                "bart-large-mnli-yahoo-answers"
              ]

MODELS = ["facebook/bart-large-mnli",
          "valhalla/distilbart-mnli-12-1",
          "valhalla/distilbart-mnli-12-3",
          "valhalla/distilbart-mnli-12-6",
          "valhalla/distilbart-mnli-12-9",
          "joeddav/bart-large-mnli-yahoo-answers"
          ]

'''
counts = []
counter = 0
for index, row in tweets_df.iterrows():
    tweet = str(row["Tweet"])
    counts.append(len(tweet))
    if len(tweet) < 5 :
      counter+=1

print(counter)
from statistics import mean, median
print(mean(counts), median(counts))
import matplotlib.pyplot as plt
plt.plot(counts)
plt.plot(mean(counts))
plt.plot(median(counts))
plt.show()
'''

for model, name in zip(MODELS, MODEL_NAMES):
  MODEL = model
  MODEL_NAME = name
  OUTPUT_FILE_NAME = MODEL_NAME + "-predictions.csv"

  tokenizer = AutoTokenizer.from_pretrained(MODEL)
  model = AutoModelForSequenceClassification.from_pretrained(MODEL)
  config = AutoConfig.from_pretrained(MODEL)

  classifier = pipeline(
    task = "zero-shot-classification",
    tokenizer = tokenizer,
    model = model,
    config = config
  )

  medicine_scores = []
  politics_scores = []

  for index, row in tweets_df.iterrows():
    tweet = str(row["Tweet"])
    if len(tweet) >= 0:
      result = classifier(
        sequences = tweet,
        candidate_labels = TOPICS,
        multi_class = True
      )

      a = (result["labels"][0], np.round(100 * result["scores"][0], 2))
      b = (result["labels"][1], np.round(100 * result["scores"][1], 2))

      if a[0] == TOPICS[0] :
        medicine_scores.append(a[1])
        politics_scores.append(b[1])
      else :
        medicine_scores.append(b[1])
        politics_scores.append(a[1])

    med_df = pd.DataFrame(medicine_scores)
    pol_df = pd.DataFrame(politics_scores)

    scores_df = pd.concat([med_df, pol_df], axis=1)
    scores_df.columns = TOPICS

    labels = []
    for index, row in scores_df.iterrows():
      if (row[TOPICS[0]] > row[TOPICS[1]]) and (row[TOPICS[0]] > THRESHOLD):
        labels.append(TOPICS[0])
      elif (row[TOPICS[1]] > row[TOPICS[0]]) and (row[TOPICS[1]] > THRESHOLD):
        labels.append(TOPICS[1])
      else:
        labels.append(DEFAULT_TOPIC)

    labels_df = pd.DataFrame(labels)
    results = pd.concat([scores_df, labels_df], axis=1)
    results.columns = OUTPUT_COLUMNS

    results.to_csv(OUTPUT_FILE_NAME)
